package com.flp.ems.view;

import java.util.HashMap;

import com.flp.ems.service.EmployeeServiceImpl;

import java.util.*;
/*import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import com.flp.ems.util.*;*/

public class UserInteraction {

	Scanner temp = new Scanner(System.in);
	EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();

	public void AddEmployee() {

		HashMap<String, String> create = new HashMap<String, String>();

		String Name;
		int EmployeeId;
		long Phone_Number;
		String Address;
		/*
		 * Date DateOfJoining; Date DateOfBirth;
		 */

		// NAME
		System.out.println("Enter your name");
		Name = temp.next();
		create.put("Name", Name);

		// EMPID
		System.out.println("Enter your employee id");
		EmployeeId = temp.nextInt();
		create.put("EmployeeId", String.valueOf(EmployeeId));

		// PhnNumber
		System.out.println("Enter your contact number");
		Phone_Number = temp.nextLong();
		create.put("Phone Number", String.valueOf(Phone_Number));

		// Address
		System.out.println("Enter your address");
		Address = temp.next();
		create.put("Address", Address);

		// DateFormat df = new SimpleDateFormat("MM/dd/yyyy");

		/*
		 * //DateofJoining System.out.println("Enter your date of joining");
		 * 
		 * create.put("Date Of Joining", temp1);
		 * 
		 * //DateofBirth System.out.println("Enter your date of birth");
		 * 
		 * create.put("Date Of Birth", temp1);
		 */

		empserimpl.AddEmployee(create);

	}

	public boolean ModifyEmployee() {

		return true;
	}

	public boolean RemoveEmplooye() {

		return true;
	}

	public void SearchEmployee() {

		System.out.println("Enter the id of the employee to be searched");
		int id = temp.nextInt();
		String employeeDetail = empserimpl.SearchEmployee(id);
		if (employeeDetail == null) {
			System.out.println("Employeee not found");
		}
		System.out.println(employeeDetail);
	}

	public boolean getAllEmployee() {

		return true;
	}

}
