package com.flp.ems.util;

public class Validate {
	
	public static boolean validateName()
	{
		
		return true;
	}
	
	public static boolean validatePhnNum()
	{
		return true;
	}
	
	public static boolean validateAddress()
	{
		return true;
	}
	
	public static boolean validateDateofJoining()
	{
		return true;
	}
	
	public static boolean validateDateofBirth()
	{
		return true;
	}
	
	

}
