package com.flp.ems.dao;

import java.util.ArrayList;
//import java.util.HashMap;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForList implements IemployeeDao {

	static ArrayList<Employee> temp = new ArrayList<>();

	public void AddEmployee(Employee e) {
		temp.add(e);
		for (Employee emp : temp)
			System.out.println(emp);

	}

	public boolean ModifyEmployee(int id) {

		return true;

	}

	public boolean RemoveEmployee(int id) {

		return true;

	}

	public Employee SearchEmployee(int id) {
		Integer id1 = id;
		for (Employee e : temp) {
			if (id1.equals(e.getEmployeeId())) {
				return e;
			}
		}
		return null;
	}

	public void getAllEmployee() {
		for (Employee e : temp)
			System.out.println(e);

	}

}
