package com.flp.ems.dao;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {

	Employee emp = new Employee();
	public void AddEmployee(Employee emp);
	public boolean ModifyEmployee(int id);
	public boolean RemoveEmployee(int id);
	public Employee SearchEmployee(int id);
	public void getAllEmployee();
}
