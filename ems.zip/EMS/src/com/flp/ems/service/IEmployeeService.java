package com.flp.ems.service;

import java.util.HashMap;

public interface IEmployeeService {
	
	public void AddEmployee(HashMap<String, String> create);
	public boolean ModifyEmployee();
	public boolean RemoveEmployee();
	public String SearchEmployee(int id);
	public boolean getAllEmployee();
	

}
