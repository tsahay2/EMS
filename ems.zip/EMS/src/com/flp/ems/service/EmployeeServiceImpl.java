package com.flp.ems.service;

import java.util.HashMap;

import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.domain.Employee;

public class EmployeeServiceImpl implements IEmployeeService {

	EmployeeDaoImplForList edifl = new EmployeeDaoImplForList();

	public void AddEmployee(HashMap<String, String> create) {
		Employee temp = new Employee(create.get("Name"), create.get("Address"),
				Integer.parseInt(create.get("EmployeeId")), Long.parseLong(create.get("Phone Number")));
		edifl.AddEmployee(temp);
	}

	public boolean ModifyEmployee() {
		return true;
	}

	public boolean RemoveEmployee() {
		return true;
	}

	public String SearchEmployee(int id) {
		Employee emp = edifl.SearchEmployee(id);
		if (emp == null) {
			return null;
		}
		String empStr = emp.getName() + " " + emp.getEmployeeId() + " " + emp.getAddress();
		return empStr;
	}

	public boolean getAllEmployee() {
		return true;
	}

}
